const retest = document.getElementById('retest');
retest.addEventListener('click', () => {
	window.open('index.html', '_self');
});
